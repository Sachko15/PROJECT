var values = [1,2,3,4,-4];
var check = 0;
var score = 0;
for (var i = 0; i < values.length; i++) {
	check += values[i];
	if (isNaN(values[i])) {
		console.log('Please insert a valid number!');
	}
	else if(check < 0) {
      console.log("You can't win this game!");
  }
}

